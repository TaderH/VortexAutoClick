Just run Auto1.py to automatically click download buttons.
