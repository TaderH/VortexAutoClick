import os
import pyautogui
import time

print(os.getcwd())

pyautogui.FAILSAFE = False

# Image file paths
launcher_download_path = "download_launcher.png"
website_download_path = "download_website.png"
exception_button_path = "exception_button.png"
threshold = 0.8 
retry_delay = 3 

while True:
    try:
        print("Checking for Launcher Download Button")
        launcher_location = pyautogui.locateOnScreen(launcher_download_path, confidence=threshold)

        if launcher_location is not None:
            click_x = launcher_location.left + 50
            click_y = launcher_location.top + 10
            
            pyautogui.click(click_x, click_y)
            print("Clicked on Launcher Download Button")
            time.sleep(2)

    except pyautogui.ImageNotFoundException:
        print("Launcher Download Button not found. Waiting for the element to appear.")
        time.sleep(retry_delay)

    try:
        print("Checking for Website Download Button")
        website_location = pyautogui.locateOnScreen(website_download_path, confidence=threshold)

        if website_location is not None:
            click_x = website_location.left + 50
            click_y = website_location.top + 10
            
            pyautogui.click(click_x, click_y)
            print("Clicked on Website Download Button")
            time.sleep(5.1)
            pyautogui.hotkey('ctrl', 'w')
            time.sleep(2)
            

    except pyautogui.ImageNotFoundException:
        print("Website Download Button not found. Waiting for the element to appear.")
        time.sleep(retry_delay)
